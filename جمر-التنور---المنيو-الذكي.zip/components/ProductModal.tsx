import React, { useState } from 'react';
import { MenuItem, Size, Extra, Review } from '../types';
import { CloseIcon, PlusIcon, MinusIcon, ChevronDownIcon } from './Icons';
import ImageWithFallback from './ImageWithFallback';

interface ProductModalProps {
  item: MenuItem;
  reviews: Review[];
  onClose: () => void;
  onAdd: (selectedSizes: Size[], selectedExtras: Extra[], quantity: number, notes: string, proteinType?: string) => void;
  onAddReview: (review: Omit<Review, 'id' | 'date'>) => void;
}

const CollapsibleSection: React.FC<{
  title: string;
  badge?: string;
  badgeColor?: string;
  isOpen: boolean;
  onToggle: () => void;
  children: React.ReactNode;
  disabled?: boolean;
}> = ({ title, badge, badgeColor = "bg-orange-100 text-orange-600", isOpen, onToggle, children, disabled }) => (
  <div className={`border-b border-gray-100 last:border-0 ${disabled ? 'opacity-40 pointer-events-none' : ''}`}>
    <button
      onClick={onToggle}
      disabled={disabled}
      className="w-full py-5 flex items-center justify-between group focus:outline-none"
    >
      <div className="flex items-center gap-4">
        <div className={`w-1.5 h-6 rounded-full transition-colors ${isOpen ? 'bg-orange-600' : 'bg-gray-200'}`}></div>
        <div className="text-right">
          <h3 className={`font-bold text-lg transition-colors ${isOpen ? 'text-gray-900' : 'text-gray-500'}`}>{title}</h3>
          {badge && (
            <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold mt-1 inline-block ${badgeColor}`}>
              {badge}
            </span>
          )}
        </div>
      </div>
      <div className={`p-2 rounded-xl transition-all ${isOpen ? 'bg-orange-50 text-orange-600 rotate-180' : 'bg-gray-50 text-gray-400'}`}>
        <ChevronDownIcon className="w-5 h-5" />
      </div>
    </button>
    <div className={`overflow-hidden transition-all duration-300 ${isOpen ? 'max-h-[800px] opacity-100 pb-6' : 'max-h-0 opacity-0'}`}>
      <div className="px-1">
        {children}
      </div>
    </div>
  </div>
);

const ProductModal: React.FC<ProductModalProps> = ({ item, reviews, onClose, onAdd }) => {
  const [selectedProtein, setSelectedProtein] = useState<string | undefined>(undefined);
  const [selectedSizes, setSelectedSizes] = useState<Size[]>([]);
  const [selectedExtras, setSelectedExtras] = useState<Extra[]>([]);
  const [quantity, setQuantity] = useState(1);
  const [itemNotes, setItemNotes] = useState('');
  const [isAdded, setIsAdded] = useState(false);
  
  const [tab, setTab] = useState<'options' | 'reviews'>('options');
  const [sections, setSections] = useState({
    protein: true,
    size: true,
    extras: false,
    notes: false
  });

  const toggleSection = (section: keyof typeof sections) => {
    setSections(prev => ({ ...prev, [section]: !prev[section] }));
  };

  const hasProteinTypes = item.proteinTypes && item.proteinTypes.length > 0;
  const hasSizes = item.sizes && item.sizes.length > 0;

  const handleSizeToggle = (size: Size) => {
    setSelectedSizes([size]);
    if (!sections.extras && item.extras && item.extras.length > 0) {
      setTimeout(() => toggleSection('extras'), 200);
    }
  };

  const toggleExtra = (extra: Extra) => {
    setSelectedExtras(prev => 
      prev.find(e => e.id === extra.id) 
        ? prev.filter(e => e.id !== extra.id) 
        : [...prev, extra]
    );
  };

  const canAddToCart = () => {
    if (hasProteinTypes && !selectedProtein) return false;
    if (hasSizes && selectedSizes.length === 0) return false;
    return true;
  };

  const handleAddClick = () => {
    if (!canAddToCart()) return;
    setIsAdded(true);
    onAdd(selectedSizes, selectedExtras, quantity, itemNotes, selectedProtein);
    setTimeout(() => {
      setIsAdded(false);
      onClose();
    }, 800);
  };

  const extrasTotal = selectedExtras.reduce((s, e) => s + e.price, 0);
  const sizePrice = selectedSizes.length > 0 ? selectedSizes[0].price : 0;
  const unitPrice = item.price + sizePrice + extrasTotal;
  const totalPrice = unitPrice * quantity;

  const itemReviews = reviews.filter(r => r.itemId === item.id);
  const avgRating = itemReviews.length > 0 
    ? (itemReviews.reduce((s, r) => s + r.rating, 0) / itemReviews.length).toFixed(1)
    : "4.5";

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md">
      <div className="bg-white w-full max-w-lg rounded-3xl overflow-hidden shadow-2xl animate-in zoom-in duration-300 flex flex-col max-h-[90vh]">
        {/* Product Image Header */}
        <div className="relative h-56 sm:h-72 flex-shrink-0">
          <ImageWithFallback src={item.image} alt={item.name} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
          <button 
            onClick={onClose}
            className="absolute top-4 right-4 bg-white/20 backdrop-blur-md p-2 rounded-2xl text-white hover:bg-white hover:text-gray-900 transition-all active:scale-90 border border-white/20"
          >
            <CloseIcon className="w-6 h-6" />
          </button>
          <div className="absolute bottom-6 right-6 left-6 text-white text-right">
            <h2 className="text-3xl font-black mb-1">{item.name}</h2>
            <div className="flex items-center gap-2 justify-end">
              <span className="bg-orange-600 px-3 py-1 rounded-full text-xs font-bold">★ {avgRating}</span>
              <span className="text-sm opacity-80">{item.description}</span>
            </div>
          </div>
        </div>

        {/* Modal Navigation */}
        <div className="flex bg-gray-50 p-2 m-4 rounded-2xl border border-gray-100">
          <button 
            onClick={() => setTab('options')}
            className={`flex-1 py-3 rounded-xl font-bold transition-all text-sm ${tab === 'options' ? 'bg-white text-orange-600 shadow-md' : 'text-gray-400'}`}
          >
            تخصيص الوجبة
          </button>
          <button 
            onClick={() => setTab('reviews')}
            className={`flex-1 py-3 rounded-xl font-bold transition-all text-sm ${tab === 'reviews' ? 'bg-white text-orange-600 shadow-md' : 'text-gray-400'}`}
          >
            آراء العملاء ({itemReviews.length})
          </button>
        </div>

        <div className="flex-grow overflow-y-auto px-6 pb-6 space-y-2 no-scrollbar">
          {tab === 'options' ? (
            <div className="space-y-1">
              {/* Protein/Type Options */}
              {hasProteinTypes && (
                <CollapsibleSection
                  title="النوع المفضل"
                  badge="إلزامي"
                  badgeColor="bg-red-50 text-red-600"
                  isOpen={sections.protein}
                  onToggle={() => toggleSection('protein')}
                >
                  <div className="grid grid-cols-2 gap-3">
                    {item.proteinTypes!.map((type) => (
                      <label
                        key={type}
                        className={`flex items-center justify-center p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                          selectedProtein === type 
                          ? 'border-orange-500 bg-orange-50 ring-2 ring-orange-100 shadow-sm' 
                          : 'border-gray-100 bg-gray-50 hover:bg-gray-100'
                        }`}
                      >
                        <input 
                          type="radio" className="hidden" 
                          checked={selectedProtein === type}
                          onChange={() => { setSelectedProtein(type); if (!sections.size && hasSizes) toggleSection('size'); }}
                        />
                        <span className={`font-black ${selectedProtein === type ? 'text-orange-900' : 'text-gray-700'}`}>{type}</span>
                      </label>
                    ))}
                  </div>
                </CollapsibleSection>
              )}

              {/* Size Options */}
              {hasSizes && (
                <CollapsibleSection
                  title="اختر الحجم / الكمية"
                  badge="إلزامي"
                  badgeColor="bg-red-50 text-red-600"
                  isOpen={sections.size}
                  onToggle={() => toggleSection('size')}
                  disabled={hasProteinTypes && !selectedProtein}
                >
                  <div className="space-y-3">
                    {item.sizes!.map((size) => {
                      const isSelected = !!selectedSizes.find(s => s.id === size.id);
                      return (
                        <label
                          key={size.id}
                          className={`flex items-center justify-between p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                            isSelected 
                            ? 'border-orange-500 bg-orange-50 shadow-sm' 
                            : 'border-gray-50 hover:bg-gray-100'
                          }`}
                        >
                          <input 
                            type="radio" className="hidden" 
                            checked={isSelected}
                            onChange={() => handleSizeToggle(size)}
                          />
                          <div className="flex flex-col">
                            <span className={`font-bold ${isSelected ? 'text-orange-900' : 'text-gray-700'}`}>{size.name}</span>
                            <span className="text-[10px] text-gray-400">السعر المضاف: +{size.price} ر.س</span>
                          </div>
                          <span className="font-black text-gray-900">{item.price + size.price} ر.س</span>
                        </label>
                      );
                    })}
                  </div>
                </CollapsibleSection>
              )}

              {/* Extra Add-ons */}
              {item.extras && item.extras.length > 0 && (
                <CollapsibleSection
                  title="إضافات اختيارية"
                  badge="اختياري"
                  isOpen={sections.extras}
                  onToggle={() => toggleSection('extras')}
                >
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {item.extras.map((extra) => {
                      const isSelected = !!selectedExtras.find(e => e.id === extra.id);
                      return (
                        <button
                          key={extra.id}
                          onClick={() => toggleExtra(extra)}
                          className={`flex items-center justify-between p-4 rounded-2xl border-2 transition-all text-right ${
                            isSelected ? 'border-orange-500 bg-orange-50 text-orange-900 font-bold' : 'border-gray-50 text-gray-600'
                          }`}
                        >
                          <span className="text-sm">{extra.name}</span>
                          <span className="text-xs opacity-60">+{extra.price} ر.س</span>
                        </button>
                      );
                    })}
                  </div>
                </CollapsibleSection>
              )}

              {/* Special Instructions */}
              <div className="mt-4 px-1">
                <h4 className="text-sm font-bold text-gray-800 mb-2">ملاحظات خاصة:</h4>
                <textarea
                  value={itemNotes}
                  onChange={(e) => setItemNotes(e.target.value)}
                  placeholder="مثال: بدون بصل، زيادة صوص..."
                  className="w-full p-5 rounded-2xl bg-gray-50 border border-gray-100 outline-none focus:border-orange-200 focus:bg-white transition-all text-sm resize-none text-[#000000] font-bold"
                  rows={2}
                ></textarea>
              </div>

              {/* Quantity Selector */}
              <div className="flex items-center justify-between p-4 bg-orange-50 rounded-2xl mt-6 border border-orange-100">
                <span className="font-bold text-orange-900">الكمية المطلوبة</span>
                <div className="flex items-center gap-6">
                  <button onClick={() => setQuantity(q => Math.max(1, q - 1))} className="w-10 h-10 flex items-center justify-center bg-white rounded-xl shadow-sm text-gray-400 active:scale-90 transition-all"><MinusIcon className="w-5 h-5" /></button>
                  <span className="text-xl font-black w-6 text-center text-orange-900">{quantity}</span>
                  <button onClick={() => setQuantity(q => q + 1)} className="w-10 h-10 flex items-center justify-center bg-orange-600 rounded-xl shadow-md text-white active:scale-90 transition-all"><PlusIcon className="w-5 h-5" /></button>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-4 py-4">
              {itemReviews.length > 0 ? itemReviews.map(review => (
                <div key={review.id} className="bg-gray-50 p-4 rounded-2xl border border-gray-100 space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-gray-900">{review.userName}</span>
                    <span className="text-orange-500 font-bold">★ {review.rating}</span>
                  </div>
                  <p className="text-xs text-gray-500 italic leading-relaxed">"{review.comment}"</p>
                </div>
              )) : (
                <div className="text-center py-20 text-gray-400 font-bold">لا توجد تقييمات لهذا الصنف حالياً</div>
              )}
            </div>
          )}
        </div>

        {/* Footer Add Button */}
        {tab === 'options' && (
          <div className="p-6 bg-white border-t flex-shrink-0">
            <button
              disabled={!canAddToCart() || isAdded}
              onClick={handleAddClick}
              className={`w-full py-5 rounded-3xl font-black text-xl transition-all flex items-center justify-between px-10 shadow-2xl ${
                isAdded 
                  ? 'bg-green-600 text-white translate-y-1 opacity-90' 
                  : 'bg-orange-600 text-white hover:bg-orange-700 active:scale-95 disabled:bg-gray-200 disabled:shadow-none'
              }`}
            >
              <div className="flex flex-col items-start leading-none">
                <span className="text-[10px] uppercase opacity-70 mb-1">إضافة للسلة</span>
                <span className="text-sm">
                  {isAdded ? '✅ تم الحفظ' : (canAddToCart() ? 'تأكيد الطلب' : 'أكمل الخيارات')}
                </span>
              </div>
              <div className="flex items-center gap-1">
                <span className="text-2xl">{totalPrice}</span>
                <span className="text-[10px]">ر.س</span>
              </div>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductModal;
