
import React, { useState, useEffect } from 'react';
import { CATEGORIES } from './data';
import { useCart } from './store';
import { CartIcon, TrashIcon, PlusIcon, MinusIcon, CloseIcon } from './Icons';
import ProductModal from './ProductModal';
import Dashboard from './Dashboard';
import ImageWithFallback from './ImageWithFallback';
import { MenuItem, OrderPayload } from './types';

const App: React.FC = () => {
  const { 
    menuItems, restaurantConfig, cart, orders, addOrder, addToCart, removeFromCart, updateQuantity, 
    totalAmount, isCartOpen, setIsCartOpen, orderType, setOrderType, customer, setCustomer, clearCart,
    reviews, selectedBranch, updateBranch, deliveryFee,
    updateMenuItemPrice, toggleItemVisibility, deleteMenuItem, addMenuItem, updateRestaurantConfig
  } = useCart();

  const [activeCategory, setActiveCategory] = useState(CATEGORIES[0].id);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProduct, setSelectedProduct] = useState<MenuItem | null>(null);
  const [showCheckout, setShowCheckout] = useState(false);
  const [showDashboard, setShowDashboard] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [orderSuccess, setOrderSuccess] = useState(false);
  const [notification, setNotification] = useState<string | null>(null);
  const [distanceSelected, setDistanceSelected] = useState<number | null>(null);

  const filteredItems = menuItems.filter(item => 
    item.categoryId === activeCategory && 
    item.isVisible !== false &&
    (item.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
     item.description?.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const showToast = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 3000);
  };

  const getMyLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        const url = `https://www.google.com/maps?q=${position.coords.latitude},${position.coords.longitude}`;
        setCustomer({ ...customer, locationUrl: url });
        showToast('📍 تم تحديد موقعك بنجاح');
      }, () => alert('يرجى تفعيل الـ GPS لتحديد الموقع'));
    }
  };

  const constructWhatsAppMessage = () => {
    const itemsText = cart.map(item => {
      let details = `*${item.quantity}x ${item.name}*`;
      const choices = [];
      if (item.selectedProtein) choices.push(item.selectedProtein);
      if (item.selectedSize) choices.push(item.selectedSize.name);
      if (item.selectedExtras.length > 0) choices.push(...item.selectedExtras.map(e => e.name));
      if (choices.length > 0) details += ` (${choices.join(' - ')})`;
      if (item.notes) details += `\n   📝 ملاحظة: ${item.notes}`;
      return `- ${details} = ${item.totalPrice} ر.س`;
    }).join('\n');

    let template = restaurantConfig.whatsappTemplate;
    const replacements: Record<string, string> = {
      '{branch}': selectedBranch,
      '{orderType}': orderType === 'delivery' ? 'توصيل للمنزل 🛵' : 'استلام من الفرع 🏠',
      '{items}': itemsText,
      '{subtotal}': totalAmount.toString(),
      '{deliveryFee}': orderType === 'delivery' ? (distanceSelected || 0).toString() : '0',
      '{total}': (totalAmount + (orderType === 'delivery' ? (distanceSelected || 0) : 0)).toString(),
      '{customerName}': customer.name || 'عميل جمر التنور',
      '{customerPhone}': customer.phone,
      '{customerLocation}': orderType === 'delivery' ? (customer.locationUrl || 'لم يحدد') : 'العميل سيحضر للاستلام من الفرع 🏠',
      '{customerNotes}': customer.notes || 'لا يوجد'
    };

    Object.keys(replacements).forEach(key => {
      template = template.split(key).join(replacements[key]);
    });
    return encodeURIComponent(template);
  };

  const handleConfirmOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customer.name.trim()) return alert('يرجى إدخال الاسم');
    if (!customer.phone.trim()) return alert('يرجى إدخال رقم الجوال');
    if (orderType === 'delivery') {
      if (distanceSelected === null) return alert('يرجى اختيار مسافة التوصيل لتحديد السعر');
      if (!customer.locationUrl || !customer.locationUrl.trim()) return alert('يجب تحديد الموقع لإتمام التوصيل');
    }

    setIsSubmitting(true);
    const finalFee = orderType === 'delivery' ? (distanceSelected || 0) : 0;
    const payload: OrderPayload = {
      orderType, 
      customer, 
      items: [...cart], 
      total: totalAmount + finalFee, 
      deliveryFee: finalFee, 
      timestamp: new Date().toISOString()
    };

    try {
      addOrder(payload);
      const branch = restaurantConfig.branches.find(b => b.name === selectedBranch);
      const waNumber = branch?.whatsapp || '966504322357';
      const waUrl = `https://wa.me/${waNumber}?text=${constructWhatsAppMessage()}`; 
      window.open(waUrl, '_blank');
      setOrderSuccess(true);
      clearCart();
      setDistanceSelected(null);
      setTimeout(() => { 
        setOrderSuccess(false); 
        setShowCheckout(false); 
        setIsCartOpen(false); 
      }, 3000);
    } catch (err) { alert('حدث خطأ'); } finally { setIsSubmitting(false); }
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-24" dir="rtl">
      {notification && (
        <div className="fixed top-20 inset-x-4 z-[100] animate-in slide-in-from-top">
          <div className="bg-gray-900 text-white px-6 py-3 rounded-2xl shadow-2xl mx-auto max-w-xs text-center font-bold text-sm">
            {notification}
          </div>
        </div>
      )}

      <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b px-4 py-4 flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 bg-orange-600 rounded-2xl flex items-center justify-center text-white shadow-lg cursor-pointer" onClick={() => setShowDashboard(true)}>🔥</div>
          <div>
            <h1 className="text-xl font-bold text-gray-900">جمر التنور</h1>
            <p className="text-[10px] text-orange-600 font-bold">{restaurantConfig.isOpen ? '🟢 يستقبل الطلبات' : '🔴 مغلق حالياً'}</p>
          </div>
        </div>
        <button onClick={() => setIsCartOpen(true)} className="relative p-2.5 bg-gray-100 rounded-2xl text-gray-700">
          <CartIcon className="w-6 h-6" />
          {cart.length > 0 && <span className="absolute -top-1 -right-1 bg-orange-600 text-white text-[10px] font-bold w-5 h-5 rounded-full border-2 border-white flex items-center justify-center">{cart.reduce((s,i)=>s+i.quantity, 0)}</span>}
        </button>
      </header>

      <main className="max-w-screen-md mx-auto p-4 space-y-6">
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
          {restaurantConfig.branches.map(b => (
            <button key={b.name} onClick={() => updateBranch(b.name)} className={`px-4 py-1.5 rounded-full text-xs font-bold whitespace-nowrap border transition-all ${selectedBranch === b.name ? 'bg-orange-600 border-orange-600 text-white shadow-md' : 'bg-white border-gray-200 text-gray-400'}`}>{b.name}</button>
          ))}
        </div>

        <div className="relative">
          <input type="text" placeholder="ابحث عن وجبتك المفضلة..." className="w-full p-4 pr-12 rounded-2xl bg-white shadow-sm border-none text-right outline-none focus:ring-2 focus:ring-orange-500 font-bold text-black" value={searchQuery} onChange={e => setSearchQuery(e.target.value)} />
          <span className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400">🔍</span>
        </div>
        
        <div className="flex overflow-x-auto gap-3 no-scrollbar py-2">
          {CATEGORIES.map(c => (
            <button key={c.id} onClick={() => setActiveCategory(c.id)} className={`px-5 py-3 rounded-2xl whitespace-nowrap font-bold text-sm transition-all border-2 ${activeCategory === c.id ? 'bg-orange-600 border-orange-600 text-white shadow-lg' : 'bg-white border-transparent text-gray-500'}`}>{c.icon} {c.name}</button>
          ))}
        </div>

        <div className="grid gap-3 grid-cols-2">
          {filteredItems.map(item => (
            <div key={item.id} className="bg-white p-3 rounded-3xl shadow-sm border border-transparent hover:border-orange-100 transition-all cursor-pointer group" onClick={() => setSelectedProduct(item)}>
              <div className="relative w-full aspect-square mb-3">
                <ImageWithFallback src={item.image} className="w-full h-full rounded-2xl shadow-sm" />
                <div className="absolute top-2 left-2 bg-white/90 backdrop-blur-sm px-2 py-0.5 rounded-lg font-black text-orange-600 text-[10px] shadow-sm">{item.price} ر.س</div>
              </div>
              <h3 className="font-bold text-gray-900 text-xs sm:text-sm line-clamp-1">{item.name}</h3>
              <div className="w-full bg-orange-600 text-white py-2 rounded-xl mt-3 flex items-center justify-center gap-1">
                <PlusIcon className="w-3 h-3" /><span className="text-[10px] font-bold">أضف للسلة</span>
              </div>
            </div>
          ))}
        </div>
      </main>

      {selectedProduct && <ProductModal item={selectedProduct} reviews={reviews} onClose={() => setSelectedProduct(null)} onAddReview={()=>{}} onAdd={(sizes, extras, qty, notes, protein) => { addToCart(selectedProduct, sizes, extras, qty, notes, protein); showToast(`✅ تم إضافة ${selectedProduct.name}`); }} />}

      {cart.length > 0 && !isCartOpen && (
        <div className="fixed bottom-6 inset-x-6 z-40">
          <button onClick={() => setIsCartOpen(true)} className="w-full bg-orange-600 text-white p-5 rounded-3xl font-black flex justify-between items-center shadow-2xl">
            <div className="flex items-center gap-3"><CartIcon className="w-6 h-6" /><span>عرض السلة</span></div>
            <div className="bg-white/20 px-4 py-1.5 rounded-xl">{totalAmount} ر.س</div>
          </button>
        </div>
      )}

      {isCartOpen && (
        <div className="fixed inset-0 z-50">
          <div className="absolute inset-0 bg-black/60" onClick={() => setIsCartOpen(false)}></div>
          <div className="absolute inset-y-0 left-0 max-w-full flex">
            <div className="w-screen max-w-md bg-white shadow-2xl flex flex-col">
              <div className="p-6 border-b flex justify-between items-center"><h2 className="text-2xl font-bold">السلة</h2><button onClick={() => setIsCartOpen(false)}><CloseIcon className="w-6 h-6 text-gray-500" /></button></div>
              <div className="flex-grow overflow-y-auto p-6 space-y-4 no-scrollbar">
                {cart.length === 0 ? <p className="text-center py-20 text-gray-400">السلة فارغة</p> : cart.map(item => (
                  <div key={item.cartId} className="bg-gray-50 p-4 rounded-3xl flex gap-4 items-center border">
                    <ImageWithFallback src={item.image} className="w-16 h-16 rounded-xl" />
                    <div className="flex-grow">
                      <h4 className="font-bold text-sm">{item.name}</h4>
                      <div className="flex items-center justify-between mt-2">
                        <div className="flex items-center gap-3 bg-white px-2 py-1 rounded-lg border">
                          <button onClick={() => updateQuantity(item.cartId, -1)}><MinusIcon className="w-4 h-4" /></button>
                          <span className="text-sm font-bold">{item.quantity}</span>
                          <button onClick={() => updateQuantity(item.cartId, 1)}><PlusIcon className="w-4 h-4" /></button>
                        </div>
                        <span className="font-bold text-orange-600">{item.totalPrice} ر.س</span>
                      </div>
                    </div>
                    <button onClick={() => removeFromCart(item.cartId)} className="text-red-400"><TrashIcon className="w-5 h-5" /></button>
                  </div>
                ))}
              </div>
              {cart.length > 0 && (
                <div className="p-6 border-t bg-gray-50 space-y-4">
                  <div className="flex justify-between text-2xl font-black"><span>الإجمالي</span><span>{totalAmount + (orderType === 'delivery' ? (distanceSelected || 0) : 0)} ر.س</span></div>
                  <button onClick={() => setShowCheckout(true)} className="w-full bg-orange-600 text-white py-4 rounded-3xl font-black text-lg">استمرار للطلب</button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {showCheckout && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-md">
          <div className="bg-white w-full max-w-md rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
            <div className="p-6 border-b flex justify-between items-center"><h2 className="text-2xl font-bold">إتمام الطلب</h2><button onClick={() => setShowCheckout(false)}><CloseIcon className="w-6 h-6 text-gray-500" /></button></div>
            <form onSubmit={handleConfirmOrder} className="flex-grow overflow-y-auto p-6 space-y-6 no-scrollbar">
               <div className="grid grid-cols-2 gap-4">
                  <button type="button" onClick={() => setOrderType('delivery')} className={`py-4 rounded-2xl font-bold border-2 transition-all ${orderType === 'delivery' ? 'bg-orange-50 border-orange-600 text-orange-700' : 'bg-white border-gray-100 text-gray-400'}`}>🛵 توصيل</button>
                  <button type="button" onClick={() => { setOrderType('pickup'); setDistanceSelected(0); }} className={`py-4 rounded-2xl font-bold border-2 transition-all ${orderType === 'pickup' ? 'bg-orange-50 border-orange-600 text-orange-700' : 'bg-white border-gray-100 text-gray-400'}`}>🏠 استلام</button>
               </div>
               {orderType === 'delivery' && (
                 <div className="space-y-3 p-4 bg-orange-50 rounded-2xl border border-orange-100">
                    <h4 className="text-xs font-bold text-orange-600">اختر مسافة التوصيل:</h4>
                    {[5, 7, 10].map(d => (
                      <button key={d} type="button" onClick={() => setDistanceSelected(d)} className={`w-full py-3 px-4 rounded-xl text-sm font-bold border-2 text-right flex justify-between ${distanceSelected === d ? 'bg-white border-orange-600 text-orange-600' : 'bg-white border-gray-100'}`}>
                        <span>مسافة {d === 5 ? 'قريبة' : d === 7 ? 'متوسطة' : 'بعيدة'}</span>
                        <span>{d} ر.س</span>
                      </button>
                    ))}
                 </div>
               )}
               <input required type="text" placeholder="الاسم" className="w-full p-4 rounded-2xl bg-gray-50 border-none outline-none focus:ring-2 focus:ring-orange-500 font-bold text-black" value={customer.name} onChange={e => setCustomer({...customer, name: e.target.value})} />
               <input required type="tel" placeholder="رقم الجوال" className="w-full p-4 rounded-2xl bg-gray-50 border-none outline-none focus:ring-2 focus:ring-orange-500 font-bold text-black ltr" value={customer.phone} onChange={e => setCustomer({...customer, phone: e.target.value})} />
               {orderType === 'delivery' && (
                  <div className="space-y-2">
                    <button type="button" onClick={getMyLocation} className="w-full py-4 rounded-2xl border-2 border-dashed border-orange-300 text-orange-600 font-black">📍 تحديد موقعي (GPS)</button>
                    <input required type="text" placeholder="الحي، الشارع..." className="w-full p-4 rounded-2xl bg-gray-50 border-none outline-none focus:ring-2 focus:ring-orange-500 font-bold text-black" value={customer.locationUrl} onChange={e => setCustomer({...customer, locationUrl: e.target.value})} />
                  </div>
               )}
            </form>
            <div className="p-6 bg-white border-t">
              <button disabled={isSubmitting} type="submit" onClick={handleConfirmOrder} className="w-full bg-green-600 text-white py-5 rounded-3xl font-black text-lg">
                {isSubmitting ? 'جاري الإرسال...' : (orderSuccess ? '✅ تم بنجاح' : 'تأكيد وإرسال عبر واتساب 🚀')}
              </button>
            </div>
          </div>
        </div>
      )}

      {showDashboard && <Dashboard menuItems={menuItems} restaurantConfig={restaurantConfig} orders={orders} reviews={reviews} onClose={() => setShowDashboard(false)} deleteMenuItem={deleteMenuItem} addMenuItem={addMenuItem} updateMenuItemPrice={updateMenuItemPrice} toggleItemVisibility={toggleItemVisibility} updateRestaurantConfig={updateRestaurantConfig} />}
    </div>
  );
};

export default App;
