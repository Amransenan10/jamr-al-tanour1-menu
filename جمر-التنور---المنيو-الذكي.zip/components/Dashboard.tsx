
import React, { useState, useMemo } from 'react';
import { MenuItem, Review, OrderPayload, RestaurantConfig, Category } from '../types';
import { CATEGORIES } from '../data';
import { CloseIcon, TrashIcon, StarIcon } from './Icons';

interface DashboardProps {
  menuItems: MenuItem[];
  deleteMenuItem: (id: string) => void;
  addMenuItem: (item: MenuItem) => void;
  updateMenuItemPrice: (id: string, newPrice: number) => void;
  toggleItemVisibility: (id: string) => void; 
  restaurantConfig: RestaurantConfig;
  updateRestaurantConfig: (config: RestaurantConfig) => void;
  reviews: Review[];
  orders: OrderPayload[];
  onClose: () => void;
}

type TabOption = 'overview' | 'orders' | 'menu' | 'settings';

const Dashboard: React.FC<DashboardProps> = ({ 
  menuItems, updateMenuItemPrice, toggleItemVisibility,
  restaurantConfig, updateRestaurantConfig,
  reviews, orders, onClose 
}) => {
  const [activeTab, setActiveTab] = useState<TabOption>('overview');
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);
  const [adminPassword, setAdminPassword] = useState('');
  const [passwordError, setPasswordError] = useState(false);

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminPassword === '1234') {
      setIsAdminAuthenticated(true);
      setPasswordError(false);
    } else {
      setPasswordError(true);
    }
  };

  const totalSales = useMemo(() => orders.reduce((sum, o) => sum + o.total, 0), [orders]);

  if (!isAdminAuthenticated) {
    return (
      <div className="fixed inset-0 z-[100] bg-orange-600 flex items-center justify-center p-6">
        <div className="bg-white w-full max-w-sm rounded-[2.5rem] p-10 shadow-2xl text-center space-y-8 animate-in zoom-in duration-300">
          <div className="text-6xl">🔒</div>
          <div className="space-y-2">
            <h2 className="text-2xl font-black text-gray-900">منطقة الإدارة</h2>
            <p className="text-sm text-gray-400 font-bold">يرجى إدخال كلمة المرور للوصول</p>
          </div>
          <form onSubmit={handleAdminLogin} className="space-y-4">
            <input 
              autoFocus
              type="password" 
              placeholder="****" 
              className={`w-full p-5 rounded-2xl border-2 text-center text-2xl font-black outline-none transition-all ${passwordError ? 'border-red-500 bg-red-50 animate-bounce' : 'border-gray-100 focus:border-orange-500 bg-gray-50'}`}
              value={adminPassword}
              onChange={e => setAdminPassword(e.target.value)}
            />
            <button type="submit" className="w-full bg-gray-900 text-white py-5 rounded-2xl font-black text-lg shadow-xl active:scale-95 transition-all">دخول النظام</button>
            <button type="button" onClick={onClose} className="text-gray-400 font-bold text-sm hover:text-gray-600">إلغاء والعودة</button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-[100] bg-[#fdfdfd] flex flex-col animate-in fade-in duration-300 overflow-hidden">
      <header className="bg-white border-b px-6 py-4 flex items-center justify-between shrink-0 shadow-sm">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 bg-orange-600 rounded-xl flex items-center justify-center text-white shadow-lg font-bold">🛠️</div>
          <h1 className="text-xl font-black text-gray-900">لوحة التحكم</h1>
        </div>
        <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full transition-colors"><CloseIcon className="w-6 h-6 text-gray-400" /></button>
      </header>

      <nav className="flex bg-white border-b p-2 overflow-x-auto no-scrollbar shrink-0">
        {(['overview', 'orders', 'menu', 'settings'] as TabOption[]).map(tab => (
          <button 
            key={tab} 
            onClick={() => setActiveTab(tab)}
            className={`flex-1 min-w-[100px] py-3 rounded-xl text-sm font-black transition-all ${activeTab === tab ? 'bg-orange-50 text-orange-600 shadow-inner' : 'text-gray-400 hover:text-gray-600'}`}
          >
            {tab === 'overview' && '📊 الإحصائيات'}
            {tab === 'orders' && `🛍️ الطلبات (${orders.length})`}
            {tab === 'menu' && '📋 المنيو'}
            {tab === 'settings' && '⚙️ الإعدادات'}
          </button>
        ))}
      </nav>

      <div className="flex-grow overflow-y-auto p-4 md:p-8 space-y-8">
        {activeTab === 'overview' && (
          <div className="max-w-5xl mx-auto space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white p-8 rounded-[2rem] shadow-sm border border-gray-100 flex flex-col items-center">
                <span className="text-gray-400 font-bold text-sm mb-2">إجمالي المبيعات</span>
                <span className="text-4xl font-black text-green-600">{totalSales} <small className="text-xs">ر.س</small></span>
              </div>
              <div className="bg-white p-8 rounded-[2rem] shadow-sm border border-gray-100 flex flex-col items-center">
                <span className="text-gray-400 font-bold text-sm mb-2">الطلبات المكتملة</span>
                <span className="text-4xl font-black text-gray-900">{orders.length}</span>
              </div>
              <div className="bg-white p-8 rounded-[2rem] shadow-sm border border-gray-100 flex flex-col items-center">
                <span className="text-gray-400 font-bold text-sm mb-2">حالة المطعم</span>
                <span className={`text-2xl font-black ${restaurantConfig.isOpen ? 'text-green-600' : 'text-red-600'}`}>
                  {restaurantConfig.isOpen ? 'يستقبل طلبات' : 'مغلق حالياً'}
                </span>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'orders' && (
          <div className="max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-6">
            {orders.length === 0 ? (
              <div className="col-span-full py-20 text-center text-gray-300 font-bold">لا توجد طلبات بعد</div>
            ) : orders.map((order, idx) => (
              <div key={idx} className="bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm space-y-4 hover:shadow-md transition-shadow">
                <div className="flex justify-between items-start">
                  <div className="space-y-1">
                    <h3 className="font-black text-lg text-gray-900">{order.customer.name}</h3>
                    <div className={`text-[10px] px-3 py-1 rounded-full font-black inline-block ${order.orderType === 'delivery' ? 'bg-orange-100 text-orange-600' : 'bg-green-100 text-green-600'}`}>
                      {order.orderType === 'delivery' ? '🛵 توصيل للمنزل' : '🏠 استلام من الفرع'}
                    </div>
                  </div>
                  <span className="text-[10px] text-gray-400 font-bold bg-gray-50 px-2 py-1 rounded-lg">
                    {new Date(order.timestamp).toLocaleTimeString('ar-SA')}
                  </span>
                </div>
                <div className="space-y-3 py-4 border-y border-dashed border-gray-100">
                  {order.items.map((item, i) => (
                    <div key={i} className="flex justify-between items-center text-sm">
                      <div className="font-bold text-gray-700">
                        <span className="text-orange-600 bg-orange-50 px-2 rounded-md ml-2">{item.quantity}x</span>
                        {item.name}
                        {item.selectedSize && <span className="text-[10px] text-gray-400 mr-1">({item.selectedSize.name})</span>}
                      </div>
                      <span className="font-black text-gray-900">{item.totalPrice} ر.س</span>
                    </div>
                  ))}
                </div>
                <div className="pt-2 space-y-3">
                  <div className="bg-gray-50 p-4 rounded-2xl text-[11px] font-bold text-gray-600 space-y-2">
                    <div className="flex items-center gap-2">📱 {order.customer.phone}</div>
                    <div className="flex items-start gap-2">📍 {order.customer.locationUrl || 'العميل سيحضر للفرع'}</div>
                    {order.customer.notes && <div className="text-orange-600 italic">📝 {order.customer.notes}</div>}
                  </div>
                  <div className="flex justify-between items-center font-black text-xl text-gray-900 px-2">
                    <span>الإجمالي النهائي</span>
                    <span className="text-orange-600">{order.total} <small className="text-xs">ر.س</small></span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'menu' && (
          <div className="max-w-5xl mx-auto space-y-6">
            <div className="flex justify-between items-center bg-orange-50 p-6 rounded-3xl border border-orange-100">
              <div className="space-y-1">
                <h3 className="font-black text-orange-900">إدارة القائمة</h3>
                <p className="text-xs text-orange-600 font-bold">يمكنك تغيير الأسعار أو إخفاء الأصناف من المنيو</p>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {menuItems.map(item => (
                <div key={item.id} className="bg-white p-4 rounded-3xl border border-gray-100 flex items-center gap-4 hover:border-orange-200 transition-colors group">
                  <img src={item.image} className="w-16 h-16 rounded-2xl object-cover shrink-0 grayscale group-hover:grayscale-0 transition-all" />
                  <div className="flex-grow">
                    <h4 className="font-black text-sm text-gray-900">{item.name}</h4>
                    <span className="text-[10px] text-gray-400 font-bold">{CATEGORIES.find(c => c.id === item.categoryId)?.name}</span>
                  </div>
                  <div className="flex flex-col items-end gap-2">
                    <div className="flex items-center gap-2">
                      <input 
                        type="number" 
                        className="w-20 p-2 text-center font-black text-orange-600 bg-gray-50 border rounded-xl outline-none focus:ring-2 focus:ring-orange-200"
                        value={item.price}
                        onChange={e => updateMenuItemPrice(item.id, Number(e.target.value))}
                      />
                      <span className="text-[10px] font-bold text-gray-400">ر.س</span>
                    </div>
                    <button 
                      onClick={() => toggleItemVisibility(item.id)}
                      className={`px-4 py-1.5 rounded-xl text-[10px] font-black transition-all ${item.isVisible !== false ? 'bg-green-600 text-white' : 'bg-red-50 text-red-600 border border-red-100'}`}
                    >
                      {item.isVisible !== false ? 'معروض' : 'مخفي 👁️'}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="max-w-2xl mx-auto space-y-8">
            <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-gray-100 space-y-6">
              <h3 className="text-xl font-black text-gray-900">إعدادات المتجر الأساسية</h3>
              
              <div className="space-y-4">
                <label className="text-sm font-black text-gray-500 block">حالة استقبال الطلبات</label>
                <div className="grid grid-cols-2 gap-4">
                  <button 
                    onClick={() => updateRestaurantConfig({...restaurantConfig, isOpen: true})}
                    className={`py-5 rounded-2xl font-black text-lg transition-all ${restaurantConfig.isOpen ? 'bg-green-600 text-white shadow-xl scale-105' : 'bg-gray-50 text-gray-400'}`}
                  >
                    مفتوح ✅
                  </button>
                  <button 
                    onClick={() => updateRestaurantConfig({...restaurantConfig, isOpen: false})}
                    className={`py-5 rounded-2xl font-black text-lg transition-all ${!restaurantConfig.isOpen ? 'bg-red-600 text-white shadow-xl scale-105' : 'bg-gray-50 text-gray-400'}`}
                  >
                    مغلق ❌
                  </button>
                </div>
              </div>

              <div className="space-y-4 pt-6">
                <label className="text-sm font-black text-gray-500 block">أرقام واتساب الفروع (966+)</label>
                {restaurantConfig.branches.map((b, idx) => (
                  <div key={idx} className="space-y-2">
                    <span className="text-[10px] font-black text-orange-600 pr-2">{b.name}</span>
                    <input 
                      type="text" 
                      className="w-full p-4 rounded-2xl bg-gray-50 border border-gray-100 font-black text-gray-900 outline-none focus:ring-2 focus:ring-orange-200 ltr"
                      value={b.whatsapp}
                      onChange={e => {
                        const newBranches = [...restaurantConfig.branches];
                        newBranches[idx].whatsapp = e.target.value;
                        updateRestaurantConfig({...restaurantConfig, branches: newBranches});
                      }}
                    />
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
